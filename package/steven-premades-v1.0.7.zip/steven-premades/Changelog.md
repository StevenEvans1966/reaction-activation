# steven-premades
## Realse 1.0.5
bug fixes to favored foe - added 
## Release 1.0.4
-rename to steven-premades
-added favored foe
-reworked code structure
## Release 1.0.3
-rework to remove use of hooks,
-added internal macro for absorbElements
## Release 1.0.1
correct multi user handling
## Release 1.0.1 (2023-02-21)
First release

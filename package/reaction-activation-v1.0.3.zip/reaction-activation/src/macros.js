import { absorbElements } from "./macros/absorbElements.js";
export let macros = {
	"absorbElements": absorbElements
};

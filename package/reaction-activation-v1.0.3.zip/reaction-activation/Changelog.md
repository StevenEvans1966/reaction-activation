# reaction-activation
## Release 1.0.3
-rework to remove use of hooks,
-added internal macro for absorbElements
## Release 1.0.1
correct multi user handling
## Release 1.0.1 (2023-02-21)
First release

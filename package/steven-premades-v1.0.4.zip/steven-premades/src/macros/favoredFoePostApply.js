import { debug, error, log } from "../main.js";
export async function favoredFoePostApplyDamageBonus({ speaker, actor, token, character, item, args }) {
	debug("favoredFoeDamageBonus", actor, item, args);
	const hitTargetsUuids = args[0].hitTargetUuids;
	if (hitTargetsUuids.length === 0)
		return {};
	//has hits
	try {
		const isCritical = args[0].isCritical;
		const targetUuid = hitTargetsUuids[0];
		const onUpdateTarget = actor.flags?.dae?.onUpdateTarget;
		if (onUpdateTarget) {
			const isMarked = onUpdateTarget.find(flag => flag.flagName === "Favored Foe" && flag.sourceTokenUuid === targetUuid);
			if (isMarked) {
				return await createBonusDamage(actor, targetUuid, item.system.damage.parts[0][1], isCritical, item.img);
			}
		}
		if (actor.items.find((t) => t.name === "Favored Foe").system.uses.value = 0)
			return {};
		let lastHitData = {
			targetUuid,
			damageType: item.system.damage.parts[0][1],
			isCritical: isCritical,
			attackItemImg: item.img,
			itemCardId: args[0].itemCardId,
		};
		await AddLastHit(actor, lastHitData);
		return {};
	}
	catch (error) {
		error(error);
		return {};
	}
}
export async function favoredFoePostApplyPreItemRoll({ speaker, actor, token, character, item, args }) {
	debug("favoredFoeOnUse", args);
	const attackingActor = args[0].actor;
	let lastHitData = getProperty(attackingActor.flags, "midi-qol.sreLastHit");
	if (!lastHitData) {
		error("no last hit");
		return false;
	}
	//@ts-ignore
	let target = await game.user.targets.some((t) => IsTarget(t, lastHitData.targetUuid));
	if (target)
		return true;
	//@ts-ignore
	target = await canvas.tokens.placeables.find((t) => IsTarget(t, lastHitData.targetUuid));
	if (!target) {
		error("target of lastHit not in scene");
		return false;
	}
	await target.setTarget(true, { releaseOthers: true });
	log("targeting last hit target");
	return true;
}
export async function favoredFoePostApplyOnUse({ speaker, actor, token, character, item, args }) {
	debug("favoredFoeOnUse", actor, item, args, token);
	try {
		let lastHit = getProperty(actor.flags, "midi-qol.sreLastHit");
		if (!lastHit) {
			error("no last hit");
			return;
		}
		await globalThis.MidiQOL.addConcentration(actor, { item, targets: [{ uuid: lastHit.targetUuid }] });
		await rollDamageOnFavoredFoeUsed(lastHit, actor, token);
		await removeLastHitEffect(actor);
	}
	catch (error) {
		error(error);
	}
}
function IsTarget(t, targetUuid) {
	return t.actor.uuid === targetUuid;
}
async function rollDamageOnFavoredFoeUsed(lastHit, actor, token) {
	const damageRtn = await createBonusDamage(actor, lastHit.targetUuid, lastHit.damageType, lastHit.isCritical, lastHit.attackItemImg);
	if (!damageRtn.damageRoll)
		return;
	const roll = await (new Roll(damageRtn.damageRoll).evaluate({ async: true }));
	const options = { flavor: damageRtn.flavor, itemCardId: lastHit.itemCardId, isCritical: lastHit.isCritical };
	const targets = [await fromUuid(lastHit.targetUuid)];
	await new globalThis.MidiQOL.DamageOnlyWorkflow(actor, token, roll.total, lastHit.damageType, targets, roll, options);
}
async function createBonusDamage(actor, targetUuid, damageType, isCritical, attackItemImg) {
	if (targetUuid == getProperty(actor.flags, "midi-qol.favoredFoeHit")) {
		log("Favored Foe used this turn on target");
		return {};
	}
	AddFavoredFoeHit(actor, targetUuid, attackItemImg);
	const diceMult = isCritical ? 2 : 1;
	const faces = actor.classes.ranger.scaleValues["favored-foe"].faces;
	const damageRoll = `${diceMult}d${faces}[${damageType}]`;
	return { damageRoll, flavor: "Favored Foe" };
}
async function AddLastHit(actor, lastHitData) {
	let activeEffect = findLastHitEffect(actor);
	if (!activeEffect) {
		let duration = { startRound: 0, startTurn: 0, rounds: 1, turns: 0 };
		let lastHitEffectData = {
			changes: [{
					key: "flags.midi-qol.sreLastHit",
					mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
					priority: 20,
					value: JSON.stringify(lastHitData)
				}],
			origin: actor.uuid,
			disabled: false,
			icon: lastHitData.attackItemImg,
			label: "Last Hit",
			duration
		};
		setProperty(lastHitEffectData, "flags.dae.specialDuration", ["turnEnd", "combatEnd"]);
		activeEffect = await actor.createEmbeddedDocuments("ActiveEffect", [lastHitEffectData]);
	}
	else {
		const oldChanges = activeEffect.changes;
		let changes = await duplicate(oldChanges);
		changes[0].value = JSON.stringify(lastHitData);
		await activeEffect.update({ changes });
	}
}
async function removeLastHitEffect(actor) {
	let lastHitEffect = findLastHitEffect(actor);
	if (!lastHitEffect)
		return;
	await actor.deleteEmbeddedDocuments("ActiveEffect", [lastHitEffect.id]);
}
function findLastHitEffect(actor) {
	return actor.effects.find((t) => t.label === "Last Hit");
}
async function AddFavoredFoeHit(actor, targetUuid, attackItemImg) {
	const favoredFoeHitData = {
		changes: [
			{
				key: "flags.midi-qol.favoredFoeHit",
				mode: CONST.ACTIVE_EFFECT_MODES.OVERRIDE,
				value: targetUuid,
				priority: 20
			}
		],
		origin: actor.uuid,
		disabled: false,
		icon: attackItemImg,
		label: "Favored Foe Hit",
	};
	setProperty(favoredFoeHitData, "flags.dae.specialDuration", ["turnStartSource", "combatEnd"]);
	await actor.createEmbeddedDocuments("ActiveEffect", [favoredFoeHitData]);
}

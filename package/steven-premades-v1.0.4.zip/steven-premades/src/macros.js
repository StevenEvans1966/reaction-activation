import { absorbElements } from "./macros/absorbElements.js";
import { favoredFoePostApplyPreItemRoll, favoredFoePostApplyDamageBonus, favoredFoePostApplyOnUse } from "./macros/favoredFoePostApply.js";
export let macros = {
	"absorbElements": absorbElements,
	"favoredFoePreItemRoll": favoredFoePostApplyPreItemRoll,
	"favoredFoeOnUse": favoredFoePostApplyOnUse,
	"favoredFoeDamageBonus": favoredFoePostApplyDamageBonus
};

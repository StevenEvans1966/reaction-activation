import { Register, getItem } from "../effectReg.js";
import { addReactionActivation } from "../module/reactionActivation.js";
export const reaction_filter_effect = "flags.midi-qol.reactionFilter";
Register(reaction_filter_effect, applyActiveEffect);
function applyActiveEffect(actor, change) {
	try {
		JSON.parse(change.value);
	}
	catch (error) {
		error(`${reaction_filter_effect} bad data ${change.value} ${error} on ${actor.name}`);
		return;
	}
	addReactionActivation(getItem(change).Uuid);
}

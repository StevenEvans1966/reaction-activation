import { error, log, reaction_filter_midi_qol_effect as reaction_filter_midi_qol_change_name } from "../main.js";
import { Checks } from "./checks.js";
import { showSelectDamageButtonsDialog } from "../app/selectDamageButtonsDialog.js";
import { getDamageTypeNameAndIcon } from "./config.js";
;
const ReactionActivationHookIds = new Map();
export async function addReactionActivation(itemUuid) {
	const hookName = `midi-qol.ReactionFilter.${itemUuid}`;
	//@ts-ignore
	let hooks = Hooks.events[hookName];
	let hooksArr = (hooks ? Array.from(hooks) : []);
	if (ReactionActivationHookIds.get(itemUuid) === -1 || hooksArr.length === 0) {
		addHook(itemUuid, hookName);
	}
	let removed = false;
	const currentHookId = ReactionActivationHookIds.get(itemUuid);
	for (const entry of hooksArr) {
		if (entry.id !== currentHookId) {
			Hooks.off(hookName, entry.id);
			removed = true;
		}
	}
	if (removed) {
		//@ts-ignore
		hooks = Hooks.events[hookName];
		hooksArr = (hooks ? Array.from(hooks) : []);
		if (hooksArr.length === 0) {
			addHook(itemUuid, hookName);
		}
	}
}
async function itemReactionFilterCallback(item, options) {
	const itemUuid = item.uuid;
	const workflowOptions = options.workflowOptions;
	if (!workflowOptions.reactionChecks) {
		workflowOptions.reactionChecks = [];
	}
	let checks = workflowOptions.reactionChecks?.find(check => check.itemUuid = itemUuid);
	if (!checks) {
		checks = new Checks(itemUuid);
		workflowOptions.reactionChecks?.push(checks);
	}
	const triggeringDamageTypes = getReactionActivationDamageTypes(item);
	checks.checkDamageType(workflowOptions, triggeringDamageTypes);
}
export async function removeReactionActivation(itemUuid) {
	const hookId = ReactionActivationHookIds.get(itemUuid);
	if (hookId) {
		Hooks.off(`midi-qol.ReactionFilter.${itemUuid}`, hookId);
		log(`removing reactionActivationHook for ${itemUuid}`);
	}
}
export async function getDamageTypeForReaction(workflowOptions, item) {
	const results = workflowOptions.reactionChecks;
	if (!results) {
		const damageTypes = getReactionActivationDamageTypes(item);
		if (!damageTypes) {
			error("no damage types set");
			return;
		}
		return await showSelectDamageButtonsDialog(damageTypes, damageTypes[0], "Unable to determine damage type. You are on your own");
	}
	const itemUuid = item.uuid;
	const result = results.find(check => check.itemUuid = itemUuid);
	if (!result) {
		error(`no check results for item ${itemUuid}`);
		return;
	}
	const damageCheck = result.damageTypeCheck;
	if (!damageCheck) {
		error(`no damage check results for item ${itemUuid}`);
		return;
	}
	const reactingTo = damageCheck.reactingTo;
	const defaultValue = reactingTo[0].type;
	if (reactingTo.length === 1) {
		log(`auto selecting damage as ${defaultValue}`);
		return { damageType: defaultValue, nameAndIcon: getDamageTypeNameAndIcon(defaultValue) };
	}
	const flavor = `Recommend selection <b>${defaultValue}</b> Damage ${reactingTo.map((dd) => `${dd.damage}[${dd.type}]`).join(", ")}`;
	const damageType = await showSelectDamageButtonsDialog(reactingTo.map((damageDetail) => damageDetail.type), defaultValue, flavor);
	if (!damageType) {
		error("no damage type selected");
		return;
	}
	return damageType;
}
async function addHook(itemUuid, hookName) {
	ReactionActivationHookIds.set(itemUuid, Hooks.on(hookName, itemReactionFilterCallback));
	log(`adding reactionActivationHook for ${itemUuid}`);
}
export function getReactionActivationDamageTypes(item) {
	let change = find_reaction_filter_midi_qol_change(item);
	if (!change) {
		return [];
	}
	const data = JSON.parse(change.value);
	return data.damageTypes;
}
function find_reaction_filter_midi_qol_change(item) {
	for (const e of item.effects) {
		//@ts-ignore
		for (const c of e.changes) {
			if (c.key === reaction_filter_midi_qol_change_name) {
				return c;
			}
		}
	}
	error(`cant find ${reaction_filter_midi_qol_change_name}`);
	return undefined;
}

# reaction-activation
## Release 1.0.1
correcting event registration to gm or owner
## Release 1.0.1 (2023-02-21)
First release

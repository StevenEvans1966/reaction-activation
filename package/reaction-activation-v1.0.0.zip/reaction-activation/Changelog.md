# My Module

## Release 1.0.0 (2023-02-21)
First release

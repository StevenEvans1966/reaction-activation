import { Register } from "../effectReg.js";
import { addReactionActivation } from "../module/reactionActivation.js";
export const REACTION_FILTER_NAME = "flags.midi-qol.reactionFilter";
Register(REACTION_FILTER_NAME, applyActiveEffect);
function applyActiveEffect(actor, change) {
	try {
		JSON.parse(change.value);
	}
	catch (error) {
		error(`${REACTION_FILTER_NAME} bad data ${change.value} ${error} on ${actor.name}`);
		return;
	}
	//@ts-ignore
	addReactionActivation(change.effect.origin);
}

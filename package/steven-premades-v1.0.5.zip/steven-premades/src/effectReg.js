export let activeEffectsReg = new Map();
export function Register(key, func) {
	activeEffectsReg.set(key, func);
}
